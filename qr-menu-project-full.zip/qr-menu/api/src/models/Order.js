import mongoose from 'mongoose';
const OrderSchema = new mongoose.Schema({
  table: { type: mongoose.Schema.Types.ObjectId, ref: 'Table' },
  items: [{ item: {type: mongoose.Schema.Types.ObjectId, ref:'MenuItem'}, qty: Number }],
  status: { type: String, enum: ['pending','preparing','served','paid'], default: 'pending' },
  total: Number,
  phone: String,
  feedback: { type: String }
},{timestamps:true});
export default mongoose.model('Order', OrderSchema);