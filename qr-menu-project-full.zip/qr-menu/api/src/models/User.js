import mongoose from 'mongoose';
const UserSchema = new mongoose.Schema({
  name: String,
  phone: String,
  role: { type: String, enum: ['admin','waiter'], default: 'waiter' }
},{timestamps:true});
export default mongoose.model('User', UserSchema);