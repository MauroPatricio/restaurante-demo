import mongoose from 'mongoose';
const MenuItemSchema = new mongoose.Schema({
  restaurant: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant' },
  name: String,
  price: Number,
  eta: Number // minutes to prepare
},{timestamps:true});
export default mongoose.model('MenuItem', MenuItemSchema);