import mongoose from 'mongoose';
const RestaurantSchema = new mongoose.Schema({
  name: String,
  address: String
},{timestamps:true});
export default mongoose.model('Restaurant', RestaurantSchema);