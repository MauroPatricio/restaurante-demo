import express from 'express';
import Restaurant from '../models/Restaurant.js';
import Table from '../models/Table.js';
import MenuItem from '../models/MenuItem.js';
import Order from '../models/Order.js';
import Audience from '../models/Audience.js';
import QRCode from 'qrcode';

const router = express.Router();

// Criar restaurante
router.post('/restaurants', async(req,res)=>{
  const r = await Restaurant.create(req.body);
  res.json(r);
});

// Criar mesa com QR
router.post('/tables', async(req,res)=>{
  const {restaurant, number} = req.body;
  const qrData = `https://qrmenu.app/table/${number}`;
  const qrCode = await QRCode.toDataURL(qrData);
  const t = await Table.create({restaurant, number, qrCode});
  res.json(t);
});

// Listar menu
router.get('/menu/:restaurantId', async(req,res)=>{
  const items = await MenuItem.find({restaurant:req.params.restaurantId});
  res.json(items);
});

// Criar pedido
router.post('/orders', async(req,res)=>{
  const o = await Order.create(req.body);
  if(o.phone) await Audience.create({restaurant:req.body.restaurant, phone:o.phone});
  res.json(o);
});

// Atualizar status pedido
router.patch('/orders/:id', async(req,res)=>{
  const o = await Order.findByIdAndUpdate(req.params.id, req.body, {new:true});
  res.json(o);
});

// Enviar broadcast
router.post('/broadcast', async(req,res)=>{
  const {restaurant, message} = req.body;
  const phones = await Audience.find({restaurant});
  // aqui integrar com SMS/WhatsApp API
  res.json({sent: phones.length, message});
});

export default router;