import React from 'react';
import { View, Text } from 'react-native';
export default function OrderStatusScreen(){return <View><Text>Status</Text></View>}
