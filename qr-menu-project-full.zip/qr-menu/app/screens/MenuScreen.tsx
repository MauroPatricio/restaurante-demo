import React from 'react';
import { View, Text } from 'react-native';
export default function MenuScreen(){return <View><Text>Menu</Text></View>}
