import React from 'react';
import { View, Text } from 'react-native';
export default function CartScreen(){return <View><Text>Cart</Text></View>}
