import React from 'react';
import { View, Text } from 'react-native';
export default function MenuEditor(){return <View><Text>Menu Editor</Text></View>}
