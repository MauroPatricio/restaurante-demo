import React from 'react';
import { View, Text } from 'react-native';
export default function Dashboard(){return <View><Text>Admin Dashboard</Text></View>}
